package com.example.my_school_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Listview_student_info_teacher_site extends AppCompatActivity {
    String [] info_stu={"Class 1","Class 2","Class 3","Class 4","class 5"};
    ListView lv_info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview_student_info_teacher_site);
        lv_info=(ListView)findViewById(R.id.list_info2);
        List<String> list=new ArrayList<>();
        for(String i: info_stu){
            list.add(i);
        }
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,R.layout.list_adapter,R.id.text1,list);
        lv_info.setAdapter(adapter);


    }
}
