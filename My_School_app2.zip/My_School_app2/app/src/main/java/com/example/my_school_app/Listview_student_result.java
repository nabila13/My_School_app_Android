package com.example.my_school_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Listview_student_result extends AppCompatActivity {
    String [] stu3={"Class 1","Class 2","Class 3","Class 4","class 5"};
    ListView lv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview_student_result);
        lv3=(ListView)findViewById(R.id.list_result);
        List<String> list=new ArrayList<>();
        for(String i: stu3){
            list.add(i);
        }
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,R.layout.list_adapter,R.id.text1,list);
        lv3.setAdapter(adapter);
    }
}
