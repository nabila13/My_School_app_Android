package com.example.my_school_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Listview_student_info extends AppCompatActivity {
String [] stu={"Class 1","Class 2","Class 3","Class 4","class 5"};
ListView lv;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview_student_info);
         lv=(ListView)findViewById(R.id.list1);
    List<String>list=new ArrayList<>();
    for(String i: stu){
    list.add(i);
    }
    ArrayAdapter<String> adapter=new ArrayAdapter<>(this,R.layout.list_adapter,R.id.text1,list);
    lv.setAdapter(adapter);
      }
}
